import pygame
from sys import exit

def player_animation():
    global player_surface, player_index

    if player_rect.bottom < 300:
        player_surface = player_jump
    else:
        player_index += 0.1
        if player_index >= len(player_walk):
            player_index = 0
        player_surface = player_walk[int(player_index)]

pygame.init()
screen = pygame.display.set_mode((800,400))
pygame.display.set_caption('Runner')
clock = pygame.time.Clock()

#test_surface = pygame.Surface((100,200))
#test_surface.fill('green')

test_font = pygame.font.Font(None ,50)



sky_surface = pygame.image.load('graphics/Sky.png').convert()
ground_surface = pygame.image.load('graphics/ground.png').convert()
text_surface = test_font.render('My game', False, 'white')
snail_surface = pygame.image.load('graphics/snail/snail1.png').convert_alpha()
player_walk_1 = pygame.image.load('graphics/player/player_walk_1.png').convert_alpha()
player_walk_2 = pygame.image.load('graphics/player/player_walk_2.png').convert_alpha()
player_walk = [player_walk_2, player_walk_1]
player_jump = pygame.image.load('graphics/player/jump.png').convert_alpha()
player_index = 0
player_surface = player_walk[player_index]

player_rect = player_surface.get_rect(midbottom = (80, 300))

snail_rect = snail_surface.get_rect(bottomright = (600, 300))
snailxpos = 650
snaildir = 'left'

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()

    screen.blit(sky_surface,(0,0))
    screen.blit(ground_surface,(0,300))
    screen.blit(text_surface,(300,50))
    
    screen.blit(snail_surface,(snail_rect))
    player_animation()
    screen.blit(player_surface,(player_rect))
    snail_rect.x -= 4
    if snail_rect.right <= 0:
        snail_rect.left = 800
    
    pygame.display.update()
    clock.tick(60)
    keys = pygame.key.get_pressed()
    if keys [pygame.K_d]:
        player_rect.x += 1
    keys = pygame.key.get_pressed()
    if keys [pygame.K_a]:
        player_rect.x -= 1
    keys = pygame.key.get_pressed()
    if keys [pygame.K_SPACE]:
        i = 0
        for i in range (2):
            player_rect.y += 1
            i+=1
            for i in range (2):
                i+= 1
                player_rect.y -= 1
