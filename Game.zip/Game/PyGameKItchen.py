import pygame
from sys import exit
screen = pygame.display.set_mode((1000,1000))
player_index = 0
player2_index = 0
StoveAnimation = 0
Stove2Animation = 0
BurgerTime = 30
Stove1Timer = 0
Stove2Timer = 0
player1_inv = 'None'
player2_inv = 'None'
stove1Slot = 'None'
stove2Slot = 'None'
P1invID = 0
P2invID = 0
StoveTimerStage = 0
BMS_Stand = []

def player_animation():
    global Player1walk, player_index, Player1_surf, Player2walk, player2_index, Player2_surf

    if down=="Y":
        player_index += 0.1
        if player_index >= 2:
            player_index = 0
        Player1_surf = Player1walk[int(player_index)]
        Player1_surf = pygame.transform.scale(Player1_surf, PlayerImgSize)
    elif right=="Y":
        player_index += 0.1
        if player_index < 2:
            player_index = 3
        if player_index >= 4:
            player_index = 2
        Player1_surf = Player1walk[int(player_index)]
        Player1_surf = pygame.transform.scale(Player1_surf, PlayerImgSize)
    elif left=="Y":
        player_index += 0.1
        if player_index < 2:
            player_index = 3
        if player_index >= 4:
            player_index = 2
        Player1_surf = Player1walk[int(player_index)]
        Player1_surf = pygame.transform.scale(Player1_surf, PlayerImgSize)
        Player1_surf = pygame.transform.flip(Player1_surf, 180, 0)
    elif up=="Y":
        player_index += 0.1
        if player_index < 4:
            player_index = 5
        if player_index >= 6:
            player_index = 4
        Player1_surf = Player1walk[int(player_index)]
        Player1_surf = pygame.transform.scale(Player1_surf, PlayerImgSize)
    else:
        player_index += 0.1
        if player_index < 6:
            player_index = 6
        if player_index >= 9:
            player_index = 6
        Player1_surf = Player1walk[int(player_index)]
        Player1_surf = pygame.transform.scale(Player1_surf, PlayerImgSize)
    
    if down2=="Y":
        player2_index += 0.1
        if player2_index >= 2:
            player2_index = 0
        Player2_surf = Player2walk[int(player2_index)]
        Player2_surf = pygame.transform.scale(Player2_surf, PlayerImgSize)
    elif right2=="Y":
        player2_index += 0.1
        if player2_index < 2:
            player2_index = 3
        if player2_index >= 4:
            player2_index = 2
        Player2_surf = Player2walk[int(player2_index)]
        Player2_surf = pygame.transform.scale(Player2_surf, PlayerImgSize)
    elif left2=="Y":
        player2_index += 0.1
        if player2_index < 2:
            player2_index = 3
        if player2_index >= 4:
            player2_index = 2
        Player2_surf = Player2walk[int(player2_index)]
        Player2_surf = pygame.transform.scale(Player2_surf, PlayerImgSize)
        Player2_surf = pygame.transform.flip(Player2_surf, 180, 0)
    elif up2=="Y":
        player2_index += 0.1
        if player2_index < 4:
            player2_index = 5
        if player2_index >= 6:
            player2_index = 4
        Player2_surf = Player2walk[int(player2_index)]
        Player2_surf = pygame.transform.scale(Player2_surf, PlayerImgSize)
    else:
        player2_index += 0.1
        if player2_index < 6:
            player2_index = 6
        if player2_index >= 9:
            player2_index = 6
        Player2_surf = Player2walk[int(player2_index)]
        Player2_surf = pygame.transform.scale(Player2_surf, PlayerImgSize)

#def Stove(StoveTime):
#    global StoveAnimation
#    StoveTime -=.1
#    print(StoveTime)
#    while StoveTime != 0:
#        StoveAnimation = 1
#    else:
#        StoveAnimation = 0


pygame.init()
pygame.display.set_caption("Whatcha Makin'?")
GroundImgSize = (1000, 1000)
PlayerImgSize = (100, 100)
clock = pygame.time.Clock()
ground_surf = pygame.image.load('graphics/Wood_Tiling.png').convert_alpha()

P1inv = pygame.image.load('graphics/P1_inv.png').convert_alpha()
P1inv_rect = P1inv.get_rect(midbottom = (40,100))
P1inv = pygame.transform.scale(P1inv, (130,130))
P1items_nothing = pygame.image.load('graphics/None.png').convert_alpha()
P1items_RawBurger = pygame.image.load('graphics/Raw_Burger.png').convert_alpha()
P1items_CookedBurger = pygame.image.load('graphics/Cooked_Burger.png').convert_alpha()
P1items_Lettuce = pygame.image.load('graphics/Lettuce.png').convert_alpha()
P1items_Bun = pygame.image.load('graphics/Bun.png').convert_alpha()
P1items_P2 = pygame.image.load('graphics/2Patty.png').convert_alpha()
P1items_P2L = pygame.image.load('graphics/2Patty&Lettuce.png').convert_alpha()
P1items_PL = pygame.image.load('graphics/1Patty&Lettuce.png').convert_alpha()


P1item = [P1items_nothing, P1items_RawBurger, P1items_CookedBurger, P1items_Lettuce, P1items_Bun, 
          P1items_P2, P1items_P2L, P1items_PL]
P1item_surf = P1item[P1invID]
P1items_rect = P1item_surf.get_rect(midbottom = (40, 100))
P1item_surf = pygame.transform.scale(P1item_surf, (530,530))

P2inv = pygame.image.load('graphics/P1_inv.png').convert_alpha()
P2inv_rect = P2inv.get_rect(midbottom = (40,240))
P2inv = pygame.transform.scale(P2inv, (130,130))
P2items_nothing = pygame.image.load('graphics/None.png').convert_alpha()
P2items_RawBurger = pygame.image.load('graphics/Raw_Burger.png').convert_alpha()
P2items_CookedBurger = pygame.image.load('graphics/Cooked_Burger.png').convert_alpha()
P2items_Lettuce = pygame.image.load('graphics/Lettuce.png').convert_alpha()
P2items_Bun = pygame.image.load('graphics/Bun.png').convert_alpha()
P2items_P2 = pygame.image.load('graphics/2Patty.png').convert_alpha()
P2items_P2L = pygame.image.load('graphics/2Patty&Lettuce.png').convert_alpha()
P2items_PL = pygame.image.load('graphics/1Patty&Lettuce.png').convert_alpha()


P2item = [P2items_nothing, P2items_RawBurger, P2items_CookedBurger, P2items_Lettuce, P2items_Bun,
          P2items_P2, P2items_P2L, P2items_PL]
P2item_surf = P2item[P2invID]
P2items_rect = P2item_surf.get_rect(midbottom = (40, 100))
P2item_surf = pygame.transform.scale(P2item_surf, (530,530))


P2inv = pygame.image.load('graphics/P2_inv.png').convert_alpha()
P2inv_rect = P2inv.get_rect(midbottom = (40,240))
P2inv = pygame.transform.scale(P2inv, (130,130))

#stove 
stoveOn = pygame.image.load('graphics/stove[On].png').convert_alpha()
stoveOff = pygame.image.load('graphics/stove[Off].png').convert_alpha()
StoveSprites = [stoveOff, stoveOn]
stove_surf = StoveSprites[StoveAnimation]
stove_rect = stove_surf.get_rect(midbottom= (400,700))
stove_mask = pygame.mask.from_surface(stove_surf)
stoveMaskImage = stove_mask.to_surface()

#stove 2
stove2On = pygame.image.load('graphics/stove[On].png').convert_alpha()
stove2Off = pygame.image.load('graphics/stove[Off].png').convert_alpha()
Stove2Sprites = [stove2Off, stove2On]
stove2_surf = Stove2Sprites[Stove2Animation]
stove2_rect = stove2_surf.get_rect(midbottom= (500,700))
stove2_mask = pygame.mask.from_surface(stove2_surf)
stove2MaskImage = stove2_mask.to_surface()

#stove timer
Stove1_VT0 = pygame.image.load('graphics/StoveTimer/stovetimer[0].png').convert_alpha()
Stove1_VT1 = pygame.image.load('graphics/StoveTimer/stovetimer[1].png').convert_alpha()
Stove1_VT2 = pygame.image.load('graphics/StoveTimer/stovetimer[2].png').convert_alpha()
Stove1_VT3 = pygame.image.load('graphics/StoveTimer/stovetimer[3].png').convert_alpha()
Stove1_VT4 = pygame.image.load('graphics/StoveTimer/stovetimer[4].png').convert_alpha()
Stove1_VT5 = pygame.image.load('graphics/StoveTimer/stovetimer[5].png').convert_alpha()
Stove1_VT6 = pygame.image.load('graphics/StoveTimer/stovetimer[6].png').convert_alpha()
Stove1_VT7 = pygame.image.load('graphics/StoveTimer/stovetimer[7].png').convert_alpha()
Stove1_VT8 = pygame.image.load('graphics/StoveTimer/stovetimer[8].png').convert_alpha()
Stove1_VT9 = pygame.image.load('graphics/StoveTimer/stovetimer[9].png').convert_alpha()
Stove1_VT10 = pygame.image.load('graphics/StoveTimer/stovetimer[10].png').convert_alpha()
Stove1_VT11 = pygame.image.load('graphics/StoveTimer/stovetimer[11].png').convert_alpha()
Stove1_VT12 = pygame.image.load('graphics/StoveTimer/stovetimer[12].png').convert_alpha()
Stove1_VT13 = pygame.image.load('graphics/StoveTimer/stovetimer[13].png').convert_alpha()
Stove1_VT14 = pygame.image.load('graphics/StoveTimer/stovetimer[14].png').convert_alpha()
Stove1_VTNA = pygame.image.load('graphics/StoveTimer/stovetimer[None].png').convert_alpha()
stove1_VT_sprites = [Stove1_VT0, Stove1_VT1, Stove1_VT2, Stove1_VT3, Stove1_VT4, Stove1_VT5,
                  Stove1_VT6, Stove1_VT7, Stove1_VT8, Stove1_VT9, Stove1_VT10, Stove1_VT11, 
                  Stove1_VT12, Stove1_VT13, Stove1_VT14, Stove1_VTNA]
stove1_VT_surf = stove1_VT_sprites[StoveTimerStage]
stove1_VT_rect = stove1_VT_surf.get_rect(midbottom = (410, 620))

#stove timer

stove2_VT_sprites = [Stove1_VT0, Stove1_VT1, Stove1_VT2, Stove1_VT3, Stove1_VT4, Stove1_VT5,
                  Stove1_VT6, Stove1_VT7, Stove1_VT8, Stove1_VT9, Stove1_VT10, Stove1_VT11, 
                  Stove1_VT12, Stove1_VT13, Stove1_VT14, Stove1_VTNA]
stove2_VT_surf = stove2_VT_sprites[StoveTimerStage]
stove2_VT_rect = stove2_VT_surf.get_rect(midbottom = (510, 620))

#Trash skrub
trash_surf = pygame.image.load('graphics/Trash.png').convert_alpha()
trash_rect = trash_surf.get_rect(midbottom = (800, 700))
trash_surf = pygame.transform.scale(trash_surf, (150,150))
trash_mask = pygame.mask.from_surface(trash_surf)
trashMaskImage = trash_mask.to_surface()

#Burger counter stand
beeftable_surf = pygame.image.load('graphics/BeefCounter.png').convert_alpha()
beeftable_rect = beeftable_surf.get_rect(midbottom = (660,640))
beeftable_surf = pygame.transform.scale(beeftable_surf, (150,150))
beeftable_mask = pygame.mask.from_surface(beeftable_surf)
beeftableMaskImage = beeftable_mask.to_surface()

#Lettuce counter stand
lettucetable_surf = pygame.image.load('graphics/LettuceCounter.png').convert_alpha()
lettucetable_rect = lettucetable_surf.get_rect(midbottom = (590,640))
lettucetable_surf = pygame.transform.scale(lettucetable_surf, (150,150))
lettucetable_mask = pygame.mask.from_surface(lettucetable_surf)
lettucetableMaskImage = lettucetable_mask.to_surface()

#bun counter stand
buntable_surf = pygame.image.load('graphics/BunCounter.png').convert_alpha()
buntable_rect = buntable_surf.get_rect(midbottom = (700,670))
buntable_surf = pygame.transform.scale(buntable_surf, (150,150))
buntable_mask = pygame.mask.from_surface(buntable_surf)
buntableMaskImage = buntable_mask.to_surface()

#burger making stand
BMS_empty =  pygame.image.load('graphics/BurgerMakingStation/BMS[Empty].png').convert_alpha()
BMS_B =  pygame.image.load('graphics/BurgerMakingStation/BMS[Bun].png').convert_alpha()
BMS_BP =  pygame.image.load('graphics/BurgerMakingStation/BMS[Bun+Patty].png').convert_alpha()
BMS_BPL =  pygame.image.load('graphics/BurgerMakingStation/BMS[Bun+Patty+Lettuce].png').convert_alpha()
BMS_B2PL =  pygame.image.load('graphics/BurgerMakingStation/BMS[Bun2+Patty+Lettuce].png').convert_alpha()
BMS_BP2 =  pygame.image.load('graphics/BurgerMakingStation/BMS[Bun+Patty2].png').convert_alpha()
BMS_B2P2 =  pygame.image.load('graphics/BurgerMakingStation/BMS[Bun2+Patty2].png').convert_alpha()
BMS_BP2L =  pygame.image.load('graphics/BurgerMakingStation/BMS[Bun+Patty2+Lettuce].png').convert_alpha()
BMS_B2P2L =  pygame.image.load('graphics/BurgerMakingStation/BMS[Bun2+Patty2+Lettuce].png').convert_alpha()

#None 1 #Bun 1 #Bun patty 2 #Bun Patty Lettuce 3 #




BMS_sprites = [BMS_empty, BMS_B, BMS_BP, BMS_BPL, BMS_B2PL, BMS_BP2, BMS_B2P2, BMS_BP2L, BMS_B2P2L]
BMS_surf = BMS_sprites[StoveTimerStage]
BMS_rect = BMS_surf.get_rect(midbottom = (260, 650))
BMS_mask = pygame.mask.from_surface(BMS_surf)
BMS_surf = pygame.transform.scale(BMS_surf,(150,150))

#Players
Player1walk1 =  pygame.image.load('graphics/Chef1(Walk).png').convert_alpha()
Player1walk2 =  pygame.image.load('graphics/Chef1(Walk2).png').convert_alpha()
Player1walk3 = pygame.image.load('graphics/Chef1(right).png').convert_alpha()
Player1walk4 = pygame.image.load('graphics/Chef1(right2).png').convert_alpha()
Player1walk5 = pygame.image.load('graphics/Chef1(Up).png').convert_alpha()
Player1walk6 = pygame.image.load('graphics/Chef1(Up2).png').convert_alpha()
Player1stand1 = pygame.image.load('graphics/Chef1(stand).png').convert_alpha()
Player1stand2 = pygame.image.load('graphics/Chef1(stand2).png').convert_alpha()
Player1stand3 = pygame.image.load('graphics/Chef1(stand3).png').convert_alpha()

Player2walk1 =  pygame.image.load('graphics/Chef2(Walk).png').convert_alpha()
Player2walk2 =  pygame.image.load('graphics/Chef2(Walk2).png').convert_alpha()
Player2walk3 = pygame.image.load('graphics/Chef2(right).png').convert_alpha()
Player2walk4 = pygame.image.load('graphics/Chef2(right2).png').convert_alpha()
Player2walk5 = pygame.image.load('graphics/Chef2(Up).png').convert_alpha()
Player2walk6 = pygame.image.load('graphics/Chef2(Up2).png').convert_alpha()
Player2stand1 = pygame.image.load('graphics/Chef2(stand).png').convert_alpha()
Player2stand2 = pygame.image.load('graphics/Chef2(stand2).png').convert_alpha()
Player2stand3 = pygame.image.load('graphics/Chef2(stand3).png').convert_alpha()



Player1walk = [Player1walk1, Player1walk2, Player1walk3, Player1walk4, Player1walk5, Player1walk6, Player1stand1, Player1stand2, Player1stand3]
Player1_surf = Player1walk[player_index]

Player1_rect = Player1_surf.get_rect(midbottom = (500, 600)).scale_by(0.45,0.5)
Player1_mask = pygame.mask.from_surface(Player1_surf)
mask_image = Player1_mask.to_surface()



#print(StoveSprites[0])
Player2walk = [Player2walk1, Player2walk2, Player2walk3, Player2walk4, Player2walk5, Player2walk6, Player2stand1, Player2stand2, Player2stand3]
Player2_surf = Player2walk[player_index]
Player2_mask = pygame.mask.from_surface(Player2_surf)
mask_image2 = Player2_mask.to_surface()


Player2_rect = Player2_surf.get_rect(midbottom = (400, 600)).scale_by(0.45,0.45)

ground_surf = pygame.transform.scale(ground_surf, GroundImgSize)

Player1_surf = pygame.transform.scale(Player1_surf, PlayerImgSize)

value = 0
speed = 1

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()  
    
    

    
    keys = pygame.key.get_pressed()
    #Player1 Controls
    if keys [pygame.K_d]:
        Player1_rect.x += 2
        if Player1_mask.overlap(Player2_mask, (Player2_rect.x - Player1_rect.x, Player2_rect.y - Player1_rect.y)):
            Player1_rect.x -= 2
        right="Y"
    else:
        right="N"
    if keys [pygame.K_a]:
        Player1_rect.x -= 2
        if Player1_mask.overlap(Player2_mask, (Player2_rect.x - Player1_rect.x, Player2_rect.y - Player1_rect.y)):
            Player1_rect.x += 2
        left="Y"
    else:
        left="N"
    if keys [pygame.K_w]:
        Player1_rect.y -= 2
        if Player1_mask.overlap(Player2_mask, (Player2_rect.x - Player1_rect.x, Player2_rect.y - Player1_rect.y)):
            Player1_rect.y += 2
        up="Y"
    else:
        up="N"
    if keys [pygame.K_s]:
        Player1_rect.y += 2
        if Player1_mask.overlap(Player2_mask, (Player2_rect.x - Player1_rect.x, Player2_rect.y - Player1_rect.y)):
            Player1_rect.y -= 2
        down="Y"
    else:
        down="N"


    print(BMS_Stand)
    if keys [pygame.K_e]: #PLAYER 1 INTERACTION KEY
        #BurgerMakingStation
        if Player1_mask.overlap(BMS_mask, (BMS_rect.x - Player1_rect.x, BMS_rect.y- Player1_rect.y)):
            if BMS_Stand == [] and player1_inv == 'Bun':
                BMS_Stand.append('Bun')
                BMS_surf = BMS_sprites[1]
                player1_inv = 'None'
            elif BMS_Stand == ['Bun'] and player1_inv == 'Cooked Burger':
                BMS_Stand.append('Patty')
                BMS_surf = BMS_sprites[2]
                player1_inv = 'None'
            #Bun Patty Route
            elif BMS_Stand == ['Bun', 'Patty'] and player1_inv == 'Cooked Burger':
                BMS_Stand.append('Patty') #2 Patties
                BMS_surf = BMS_sprites[5]
                player1_inv = 'None'
            elif BMS_Stand == ['Bun', 'Patty'] and player1_inv == 'Lettuce':
                BMS_Stand.append('Lettuce')
                BMS_surf = BMS_sprites[3]
                player1_inv = 'None'
            #Bun Patty Lettuce Bun
            elif BMS_Stand == ['Bun', 'Patty', 'Lettuce'] and player1_inv == 'Bun':
                BMS_Stand.append('Bun')
                BMS_surf = BMS_sprites[4]
                player1_inv = 'None'
            #Bun Patty2
            elif BMS_Stand == ['Bun', 'Patty', 'Patty'] and player1_inv == 'Bun':
                BMS_Stand.append('Bun')
                BMS_surf = BMS_sprites[6]
                player1_inv = 'None'
            elif BMS_Stand == ['Bun', 'Patty', 'Patty'] and player1_inv == 'Lettuce':
                BMS_Stand.append('Lettuce')
                BMS_surf = BMS_sprites[7]
                player1_inv = 'None'
            elif BMS_Stand == ['Bun', 'Patty', 'Patty', 'Lettuce'] and player1_inv == 'Bun':
                BMS_Stand.append('Bun')
                BMS_surf = BMS_sprites[8]
                player1_inv = 'None'
            elif BMS_Stand == ['Bun', 'Patty', 'Patty', 'Bun']:
                BMS_Stand.clear()
                BMS_surf = BMS_sprites[0]
                player1_inv = '2P'
            elif BMS_Stand == ['Bun', 'Patty', 'Patty', 'Lettuce', 'Bun']:
                BMS_Stand.clear()
                BMS_surf = BMS_sprites[0]
                player1_inv = '2P&L'
            elif BMS_Stand == ['Bun', 'Patty', 'Lettuce', 'Bun']:
                BMS_Stand.clear()
                BMS_surf = BMS_sprites[0]
                player1_inv = 'P&L'



        if Player1_mask.overlap(stove_mask, (stove_rect.x - Player1_rect.x, stove_rect.y- Player1_rect.y)):
            if player1_inv == 'Raw Burger' and stove1Slot == 'None':
                Stove1Timer = 30
                stove1Slot = 'Raw Burger'
                player1_inv = 'None'
            elif player1_inv == 'None' and stove1Slot == 'Cooked Burger':
                player1_inv = 'Cooked Burger'
                stove1Slot = 'None'
        #Stove 2        
        if Player1_mask.overlap(stove2_mask, (stove2_rect.x - Player1_rect.x, stove2_rect.y- Player1_rect.y)):
            if player1_inv == 'Raw Burger' and stove2Slot == 'None':
                Stove2Timer = 30
                stove2Slot = 'Raw Burger'
                player1_inv = 'None'
            elif player1_inv == 'None' and stove2Slot == 'Cooked Burger':
                player1_inv = 'Cooked Burger'
                stove2Slot = 'None'
        if Player1_mask.overlap(beeftable_mask, (beeftable_rect.x - Player1_rect.x, beeftable_rect.y- Player1_rect.y)):
            if player1_inv == 'None':
                player1_inv = 'Raw Burger'
        if Player1_mask.overlap(lettucetable_mask, (lettucetable_rect.x - Player1_rect.x, lettucetable_rect.y- Player1_rect.y)):
            if player1_inv == 'None':
                player1_inv = 'Lettuce'
        if Player1_mask.overlap(buntable_mask, (buntable_rect.x - Player1_rect.x, buntable_rect.y- Player1_rect.y)):
            if player1_inv == 'None':
                player1_inv = 'Bun'
        if Player1_mask.overlap(trash_mask, (trash_rect.x - Player1_rect.x, trash_rect.y- Player1_rect.y)):
            player1_inv = 'None'

    P1item_surf = P1item[P1invID]        
    P1item_surf = pygame.transform.scale(P1item_surf, (130,130))
    P2item_surf = P2item[P2invID]        
    P2item_surf = pygame.transform.scale(P2item_surf, (130,130))

    if Stove1Timer !=0:
        
        Stove1Timer -= 0.1
        StoveAnimation = 1
    if Stove1Timer < 0:
        StoveAnimation = 0
        Stove1Timer = 0
        if stove1Slot == 'Raw Burger':
            stove1Slot = 'Cooked Burger'

    if Stove2Timer !=0:
        
        Stove2Timer -= 0.1
        Stove2Animation = 1
    if Stove2Timer < 0:
        Stove2Animation = 0
        Stove2Timer = 0
        if stove2Slot == 'Raw Burger':
            stove2Slot = 'Cooked Burger'



    

    keys = pygame.key.get_pressed()
    #Player 2 Controls
    if keys [pygame.K_RIGHT]:
        Player2_rect.x += 2
        if Player2_mask.overlap(Player1_mask, (Player1_rect.x - Player2_rect.x, Player1_rect.y - Player2_rect.y)):
            Player2_rect.x -= 2
        right2="Y"
    else:
        right2="N"
    if keys [pygame.K_LEFT]:
        Player2_rect.x -= 2
        if Player2_mask.overlap(Player1_mask, (Player1_rect.x - Player2_rect.x, Player1_rect.y - Player2_rect.y)):
            Player2_rect.x += 2
        left2="Y"
    else:
        left2="N"
    if keys [pygame.K_UP]:
        Player2_rect.y -= 2
        if Player2_mask.overlap(Player1_mask, (Player1_rect.x - Player2_rect.x, Player1_rect.y - Player2_rect.y)):
            Player2_rect.y += 2
        up2="Y"
    else:
        up2="N"
    if keys [pygame.K_DOWN]:
        Player2_rect.y += 2
        if Player2_mask.overlap(Player1_mask, (Player1_rect.x - Player2_rect.x, Player1_rect.y - Player2_rect.y)):
            Player2_rect.y -= 2
        down2="Y"
    else:
        down2="N"
   
    if keys [pygame.K_SLASH]: #PLAYER 2 INTERATION KEY
        #BurgerMakingStation
        if Player2_mask.overlap(BMS_mask, (BMS_rect.x - Player2_rect.x, BMS_rect.y- Player2_rect.y)):
            if BMS_Stand == [] and player2_inv == 'Bun':
                BMS_Stand.append('Bun')
                BMS_surf = BMS_sprites[1]
                player2_inv = 'None'
            elif BMS_Stand == ['Bun'] and player2_inv == 'Cooked Burger':
                BMS_Stand.append('Patty')
                BMS_surf = BMS_sprites[2]
                player2_inv = 'None'
            #Bun Patty Route
            elif BMS_Stand == ['Bun', 'Patty'] and player2_inv == 'Cooked Burger':
                BMS_Stand.append('Patty') #2 Patties
                BMS_surf = BMS_sprites[5]
                player2_inv = 'None'
            elif BMS_Stand == ['Bun', 'Patty'] and player2_inv == 'Lettuce':
                BMS_Stand.append('Lettuce')
                BMS_surf = BMS_sprites[3]
                player2_inv = 'None'
            #Bun Patty Lettuce Bun
            elif BMS_Stand == ['Bun', 'Patty', 'Lettuce'] and player2_inv == 'Bun':
                BMS_Stand.append('Bun')
                BMS_surf = BMS_sprites[4]
                player2_inv = 'None'
            #Bun Patty2
            elif BMS_Stand == ['Bun', 'Patty', 'Patty'] and player2_inv == 'Bun':
                BMS_Stand.append('Bun')
                BMS_surf = BMS_sprites[6]
                player2_inv = 'None'
            elif BMS_Stand == ['Bun', 'Patty', 'Patty'] and player2_inv == 'Lettuce':
                BMS_Stand.append('Lettuce')
                BMS_surf = BMS_sprites[7]
                player2_inv = 'None'
            elif BMS_Stand == ['Bun', 'Patty', 'Patty', 'Lettuce'] and player2_inv == 'Bun':
                BMS_Stand.append('Bun')
                BMS_surf = BMS_sprites[8]
                player2_inv = 'None'
            elif BMS_Stand == ['Bun', 'Patty', 'Patty', 'Bun']:
                BMS_Stand.clear()
                BMS_surf = BMS_sprites[0]
                player2_inv = '2P'
            elif BMS_Stand == ['Bun', 'Patty', 'Patty', 'Lettuce', 'Bun']:
                BMS_Stand.clear()
                BMS_surf = BMS_sprites[0]
                player2_inv = '2P&L'
            elif BMS_Stand == ['Bun', 'Patty', 'Lettuce', 'Bun']:
                BMS_Stand.clear()
                BMS_surf = BMS_sprites[0]
                player2_inv = 'P&L'


        if Player2_mask.overlap(stove_mask, (stove_rect.x - Player2_rect.x, stove_rect.y- Player2_rect.y)):
            if player2_inv == 'Raw Burger' and stove1Slot == 'None':
                Stove1Timer = 30
                stove1Slot = 'Raw Burger'
                player2_inv = 'None'
            elif player2_inv == 'None' and stove1Slot == 'Cooked Burger':
                player2_inv = 'Cooked Burger'
                stove1Slot = 'None'
        #Stove2        
        if Player2_mask.overlap(stove2_mask, (stove2_rect.x - Player2_rect.x, stove2_rect.y- Player2_rect.y)):
            if player2_inv == 'Raw Burger' and stove2Slot == 'None':
                Stove2Timer = 30
                stove2Slot = 'Raw Burger'
                player2_inv = 'None'
            elif player2_inv == 'None' and stove2Slot == 'Cooked Burger':
                player2_inv = 'Cooked Burger'
                stove2Slot = 'None'
        if Player2_mask.overlap(beeftable_mask, (beeftable_rect.x - Player2_rect.x, beeftable_rect.y- Player2_rect.y)):
            if player2_inv == 'None':
                player2_inv = 'Raw Burger'
        if Player2_mask.overlap(lettucetable_mask, (lettucetable_rect.x - Player2_rect.x, lettucetable_rect.y- Player2_rect.y)):
            if player2_inv == 'None':
                player2_inv = 'Lettuce'
        if Player2_mask.overlap(buntable_mask, (buntable_rect.x - Player2_rect.x, buntable_rect.y- Player2_rect.y)):
            if player2_inv == 'None':
                player2_inv = 'Bun'
        if Player2_mask.overlap(trash_mask, (trash_rect.x - Player2_rect.x, trash_rect.y- Player2_rect.y)):
            player2_inv = 'None'

    if player1_inv == 'None':
        P1invID = 0
    elif player1_inv == 'Raw Burger':
        P1invID = 1
    elif player1_inv == 'Cooked Burger':
        P1invID = 2
    elif player1_inv == 'Lettuce':
        P1invID = 3
    elif player1_inv == 'Bun':
        P1invID = 4
    elif player1_inv == '2P':
        P1invID = 5
    elif player1_inv == '2P&L':
        P1invID = 6
    elif player1_inv == 'P&L':
        P1invID = 7

    
    if player2_inv == 'None':
        P2invID = 0
    elif player2_inv == 'Raw Burger':
        P2invID = 1
    elif player2_inv == 'Cooked Burger':
        P2invID = 2
    elif player2_inv == 'Lettuce':
        P2invID = 3
    elif player2_inv == 'Bun':
        P2invID = 4
    elif player2_inv == '2P':
        P2invID = 5
    elif player2_inv == '2P&L':
        P2invID = 6
    elif player2_inv == 'P&L':
        P2invID = 7
    
    
    #if Stove1Timer == 0 and stove1Slot == 'None':
            #StoveTimerStage = 15

    if stove1Slot == 'None':
        stove1_VT_surf = stove1_VT_sprites[15]

    if stove1Slot == 'Raw Burger':
        if round(Stove1Timer) == 30:
            stove1_VT_surf = stove1_VT_sprites[0]
        elif round(Stove1Timer) == 28:
            stove1_VT_surf = stove1_VT_sprites[1]
        elif round(Stove1Timer) == 26:
            stove1_VT_surf = stove1_VT_sprites[2]
        elif round(Stove1Timer) == 24:
            stove1_VT_surf = stove1_VT_sprites[3]
        elif round(Stove1Timer) == 22:
            stove1_VT_surf = stove1_VT_sprites[4]
        elif round(Stove1Timer) == 20:
            stove1_VT_surf = stove1_VT_sprites[5]
        elif round(Stove1Timer) == 18:
            stove1_VT_surf = stove1_VT_sprites[6]
        elif round(Stove1Timer) == 16:
            stove1_VT_surf = stove1_VT_sprites[7]
        elif round(Stove1Timer) == 14:
            stove1_VT_surf = stove1_VT_sprites[8]
        elif round(Stove1Timer) == 12:
            stove1_VT_surf = stove1_VT_sprites[9]
        elif round(Stove1Timer) == 10:
            stove1_VT_surf = stove1_VT_sprites[10]
        elif round(Stove1Timer) == 8:
            stove1_VT_surf = stove1_VT_sprites[11]
        elif round(Stove1Timer) == 6:
            stove1_VT_surf = stove1_VT_sprites[11]
        elif round(Stove1Timer) == 4:
            stove1_VT_surf = stove1_VT_sprites[13]
        elif round(Stove1Timer) == 2:
            stove1_VT_surf = stove1_VT_sprites[14]
        elif round(Stove1Timer) == 0 and stove1Slot == 'Cooked Burger':
            stove1_VT_surf = stove1_VT_sprites[14]
    
    if stove2Slot == 'None':
        stove2_VT_surf = stove2_VT_sprites[15]

    if stove2Slot == 'Raw Burger':
        if round(Stove2Timer) == 30:
            stove2_VT_surf = stove2_VT_sprites[0]
        elif round(Stove2Timer) == 28:
            stove2_VT_surf = stove2_VT_sprites[1]
        elif round(Stove2Timer) == 26:
            stove2_VT_surf = stove2_VT_sprites[2]
        elif round(Stove2Timer) == 24:
            stove2_VT_surf = stove2_VT_sprites[3]
        elif round(Stove2Timer) == 22:
            stove2_VT_surf = stove2_VT_sprites[4]
        elif round(Stove2Timer) == 20:
            stove2_VT_surf = stove2_VT_sprites[5]
        elif round(Stove2Timer) == 18:
            stove2_VT_surf = stove2_VT_sprites[6]
        elif round(Stove2Timer) == 16:
            stove2_VT_surf = stove2_VT_sprites[7]
        elif round(Stove2Timer) == 14:
            stove2_VT_surf = stove2_VT_sprites[8]
        elif round(Stove2Timer) == 12:
            stove2_VT_surf = stove2_VT_sprites[9]
        elif round(Stove2Timer) == 10:
            stove2_VT_surf = stove2_VT_sprites[10]
        elif round(Stove2Timer) == 8:
            stove2_VT_surf = stove2_VT_sprites[11]
        elif round(Stove2Timer) == 6:
            stove2_VT_surf = stove2_VT_sprites[11]
        elif round(Stove2Timer) == 4:
            stove2_VT_surf = stove2_VT_sprites[13]
        elif round(Stove2Timer) == 2:
            stove2_VT_surf = stove2_VT_sprites[14]
        elif round(Stove2Timer) == 0 and stove2Slot == 'Cooked Burger':
            stove2_VT_surf = stove2_VT_sprites[14]
    
    StoveTimerStage = 5

    screen.blit(ground_surf, (0, 0))
    screen.blit(stove_surf,(stove_rect))
    screen.blit(stove2_surf,(stove2_rect))

    

    screen.blit(beeftable_surf,(beeftable_rect))
    screen.blit(lettucetable_surf,(lettucetable_rect))
    screen.blit(buntable_surf,(buntable_rect))
    screen.blit(trash_surf,(trash_rect))
    screen.blit(BMS_surf,(BMS_rect))
    BMS_surf = pygame.transform.scale(BMS_surf,(150,150))
    screen.blit(P1item_surf,(P1inv_rect))
    screen.blit(P2item_surf,(P2inv_rect))
    player_animation()

    screen.blit(Player1_surf,(Player1_rect))
    screen.blit(Player2_surf,(Player2_rect))
    screen.blit(P1item_surf, (P1items_rect))

    #Player1_surf = pygame.transform.scale(Player1_surf, PlayerImgSize)
    #Player2_surf = pygame.transform.scale(Player2_surf, PlayerImgSize)
    screen.blit(stove1_VT_surf,(stove1_VT_rect))
    screen.blit(stove2_VT_surf,(stove2_VT_rect))
    screen.blit(P1inv, (P1inv_rect))
    screen.blit(P2inv, (P2inv_rect))
    
    pygame.display.update()

    clock.tick(60)