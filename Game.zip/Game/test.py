x= []


x.append('woah')

print(x)